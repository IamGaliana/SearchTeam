package com.dangdang.data;

public class FuncVP {

	private int fvp_id;
	private String fvp;
	public int getFvp_id() {
		return fvp_id;
	}
	public void setFvp_id(int fvp_id) {
		this.fvp_id = fvp_id;
	}
	public String getFvp() {
		return fvp;
	}
	public void setFvp(String fvp) {
		this.fvp = fvp;
	}
	
	
}
