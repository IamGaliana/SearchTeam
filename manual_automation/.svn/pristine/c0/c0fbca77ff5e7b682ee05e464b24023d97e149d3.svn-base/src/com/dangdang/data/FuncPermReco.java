package com.dangdang.data;

public class FuncPermReco {

	private String perm_id;
	private String brand_reco;
	public String getPerm_id() {
		return perm_id;
	}
	public void setPerm_id(String perm_id) {
		this.perm_id = perm_id;
	}
	public String getBrand_reco() {
		return brand_reco;
	}
	public void setBrand_reco(String brand_reco) {
		this.brand_reco = brand_reco;
	}
	
}
