package com.dangdang.verifier.sort.clothBzs;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Node;

import com.dangdang.client.RPCClient;
import com.dangdang.client.SearchRequester;
import com.dangdang.client.URLBuilder;
import com.dangdang.data.FuncQuery;
import com.dangdang.util.ProdIterator;
import com.dangdang.util.XMLParser;
public class ClothBusinessSortVerifier {

	// 日志记录器
	public static Logger logger = Logger.getLogger(ClothBusinessSortVerifier.class);
	static {
		PropertyConfigurator.configure("conf/clothbiz_log4j.properties");
	}
	// 属于服装事业部的类目路径
	
	/*
	 * 58.64.00.00.00.00  
58.61.00.00.00.00  
58.65.00.00.00.00  
58.74.00.00.00.00  
58.83.00.00.00.00  
58.60.00.00.00.00  
58.79.00.00.00.00  
58.81.00.00.00.00  
*/
	private static final String[] clothCategory = { "58.64.00.00.00.00", "58.61.00.00.00.00", "58.65.00.00.00.00", "58.74.00.00.00.00",
			"58.83.00.00.00.00","58.60.00.00.00.00","58.79.00.00.00.00" ,"58.81.00.00.00.00"};
	// 预设的优质商家品的位置
	private static final Integer[] pos_quality = { 1, 2, 3, 5, 6, 7, 9, 10, 11, 13, 14, 15, 17, 18, 19, 21, 22, 23, 25, 26, 29, 30, 33, 34, 37, 38,
			41, 42, 45, 46, 49, 50, 53, 54, 57, 58 };
	// 预设的新商家品的位置
	private static final Integer[] pos_new = { 4, 8, 12, 16, 20, 24 };
	// 预设的普通商家品的位置
	private static final Integer[] pos_common = { 27, 28, 31, 32, 35, 36, 39, 40, 43, 44, 47, 48, 51, 52, 55, 56, 59, 60 };


	public static List<Integer> temQulist = Arrays.asList(pos_quality);
	public static List<Integer> temNelist = Arrays.asList(pos_new);
	public static List<Integer> temColist = Arrays.asList(pos_common);
	
	
	/**
	 * 验证服装事业部新排序策略
	 * 
	 * @param fquery
	 *            输入的query对象
	 * @return
	 */
	public static boolean verify(FuncQuery fquery) {
//		NewPList.clear();
//		QuliPList.clear();
//		ComPList.clear();
//		
		// 暂存新商家位置上所有品的列表
		List<Node> NewPList = new ArrayList<Node>();
		// 暂存优质商家位置上所有品的列表
		List<Node> QuliPList = new ArrayList<Node>();
		// 暂存普通商家位置上所有品的列表
		List<Node> ComPList = new ArrayList<Node>();
		
		// 得到query词
		String query = fquery.getFquery();

		// 拿到query词的第一个分类的权重
		String firstCategory = null;

		// 第一分类的权重
		int firstPriority = 0;
		// 从接口得到查询的分类反馈信息
		Map<String, Double> priorityMap = RPCClient.getCategoryPriority(query);

		// 找到第一分类
		for (Map.Entry<String, Double> entry : priorityMap.entrySet()) {
			int priority = entry.getValue().intValue();
			if (priority > firstPriority) {
				firstPriority = priority;
				firstCategory = entry.getKey();
			}
		}

		// 查询的url参数组装
		Map<String, String> urlMap = new HashMap<String, String>();
		urlMap.put("st", "full");
		urlMap.put("um", "search_ranking");
		urlMap.put("_mod_ver", "S5");
		urlMap.put("_new_tpl", "1");
		try {
			urlMap.put("q", URLEncoder.encode(query, "GBK"));
		} catch (UnsupportedEncodingException e) {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();  
			e.printStackTrace(new PrintStream(baos));  
			String exception = baos.toString();  
			logger.error(" - [LOG_EXCEPTION] - "+exception);
		}
		
		
		
		// 得到品的迭代器
		ProdIterator iterator = new ProdIterator(urlMap);

		// 第一分类权重>=40 && 第一分类属于服装事业部分类
		if (firstPriority>=40 && isClothBzsCategory(firstCategory) && iterator.getTotalCount()>=500 ) {
			//结果中去除分类直达
			String urlStr = URLBuilder.buildUrl(urlMap);
			String xmlStr = SearchRequester.get(urlStr);
			Document doc=null;
			try {
				doc = XMLParser.read(xmlStr);
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (DocumentException e) {
				e.printStackTrace();
			}
			
			
			
			List<Node> pathList = XMLParser.pathInfo(doc);
			if(pathList!=null){
				//验证是否为分类直达(是否包含(result\StatInfo\Path节点)
				if(pathList.size()>0){
					logger.error(" - [INSIDE] - "+"Cate direct is enable in result. ");
					return false;
				}}		
			
			
			
			
			// 前五页对应位置上的品按照顺序放置到对应的列表中，方便后续使用
			while (iterator.hasNext()) {
				
				Node node = iterator.next();
				if(iterator.getpageIndex() >5){
					break;
				}

				if (temQulist.contains(iterator.getPoint() + 1)) {
					QuliPList.add(node);
				} else if (temNelist.contains(iterator.getPoint() + 1)) {
					NewPList.add(node);
				} else if (temColist.contains(iterator.getPoint() + 1)) {
					ComPList.add(node);
				} else {
					logger.error(" - [INSIDE] - " + "位置有问题");
					return false;
				}
			}
			// 优质商家shop_id列表
			List<String> QShopList = QualityShop();
			// 新商家shop_id列表
			List<String> NShopList = NewShop();

			// 优质商家的位置上是优质商家的品
			int qua_split_pos = 0;
			
			
			//去除单品置顶
			if(!rmTopProduct(QuliPList)){
				return false;
			}
			
			if (!doVerify(QuliPList, qua_split_pos, QShopList,NShopList)) {
				logger.error("[Quality]");
				return false;
			}

			// 新商家的位置上是新商家的品
			int new_split_pos = 0;
			if (!doVerify(NewPList, new_split_pos, NShopList,QShopList)) {
				logger.error("[New]");
				return false;
			}

			// 普通商品的位置上是普通商家，并且按照Score的分数降序排列
//			int pre_score = -1; // 初始化
			for (int x=0;x<ComPList.size();x++) {
				Node node = ComPList.get(x);
//				String score = XMLParser.product_scope(node);
				String shop_id = XMLParser.product_shopID(node);
				// 普通品位置只能包含普通商品的品
				if (QShopList.contains(shop_id) || NShopList.contains(shop_id)) {
					if(!noProperProduct(ComPList, QShopList, NShopList)){
					logger.error(" - [INSIDE] - "+" - Quality/New shop Product was found at commons product's position. "+PositionCom(x));
					logger.error(" - [INSIDE] - "+" Product ID:"+shop_id+" Position: "+ComPList.indexOf(node));
					return false;
					}
					
					
					//是否连续
					for(int y=x;y<ComPList.size();y++){
						String tem_shop_id = XMLParser.product_shopID(ComPList.get(y));
						String tem_product_id = XMLParser.product_id(ComPList.get(y));
						if(QShopList.contains(tem_shop_id) || NShopList.contains(tem_shop_id)){
							continue;
						}else{
							logger.error(" - [INSIDE] - "+"The Common product type list is discontinuity.Position:"+PositionCom(y));
							logger.error(" - [INSIDE] - "+"The product__id:"+tem_product_id);
							return false;
						}
					}
				}

//				if (pre_score == -1) {
//					pre_score = Integer.valueOf(score);
//					continue;
//				} else {
//					if (pre_score >= Integer.valueOf(score)) {
//						continue;
//
//						// 没有按照score分进行排序
//					} else {
//						logger.error(" - [INSIDE] - "+" - Sort by score failed. product_id:"+XMLParser.product_id(node)+" Score:"+score+"  "+PositionCom(x));
//						return false;
//					}
//				}
			}
			// 如果不进入服装事业部重新排序的要求
		} else {
			return true;    // SortScore(iterator);   含有打散等策略，不能按照score分排序验证
		}
		logger.info(" - [INSIDE] - "+"Verify Successed!");
		return true;
	}

	/**
	 * 判断是否属于服装事业部的分类
	 * 
	 * @param catePath
	 * @return
	 */
	public static boolean isClothBzsCategory(String catePath) {
			//遍历服装是业务负责的分类
		for (String cpath : clothCategory){
			//获得主分类
			String cate_head = org.apache.commons.lang3.StringUtils.substring(cpath,0,5);
			if(catePath!=null && catePath.length()>5){
			//获得目标分类的主分类
			String catePath_head = org.apache.commons.lang3.StringUtils.substring(catePath,0,5);
			//如果属于服装事业部负责
			if(cate_head.equals(catePath_head)){
				return true;
			}
			}
		}
		return false;
	}

	/**
	 * 生成优质商家的列表
	 * 
	 * @return
	 */
	public static List<String> QualityShop() {
		String QualityShop = "6575,4609,10188,9460,9628,5936,9801,10948,8746,6986,9801,6489,7267,10464,10793,7192,7942,8323,8546,8939,13240,13993,10876,7752,11513,8294,5384,7710,8156,7344,8131,7479,7014,14050,8862,8132,9902,5941,9943,13216,14041,8923,8214,9625,14044,12932,7171,10153,14072,14048,9497,13715,13492,11658,13824,12646,14244,7386,8205,8296,14915,8104,13235,13767,12350,9175,12692,12859,13210,13670,7347,8525,10723,7127,12560,5372,10174,13836,12771,7584,6511,12838,7325,11595,9956,14049,6657,12962,4390,9220,11109,11377,10869,11106,8023,9903,11730,12612,7133,14102,13880,13833,13696,13526,13477,13047,12955,12786,12408,11596,11324,10671,10459,10240,9847,9641,9451,9323,9280,9273,9248,9195,9128,9056,8827,8781,8545,8328,8279,8077,7968,7774,7762,7494,7387,7292,6870,6208,6100,4994,4264,9335,9320,5261,7831,7658,10858,8038,12307,12797,12401,13449,9002,6549,8361,8734,11845,6728,6748,14001,8258,9547,12780,13144,8924,7486,9433,12488,8914,8560,9556,9769,10823,13396,7789,9675,13859,12279,13840,8093,14973,5871,10440,8843,9194,4550,7626,8931,7081,8162,12339,9104,7326,7550,14380,7212,9110,8327,10018,9566,9728,7777,12999,10696,7869,9003,5134,6524,8600,6553,6888,9555,4979,4280,12404,3827,5976,8333,6999,9649,12998,9765,8887,7465,9704,3782,13328,7954,4535,12965,5054,7617,6074,6297,7535,11278,8880,10353,12300,12689,9957,7834,9568,9136,9154,9176,9193,9181,7723,8410,4855,9093,6881,7600,13062,11387,7522,6492,10148,9504,7982,3695,4476,4664,367,9478,9410,7577,11563,12562,4799,5187,8627,10833,6041,10762,10681,6038,10341,12000,6638,10005,9463,14160,13900,9253,10598,9609,11971,10052,9950,5968,6604,6720,6633,9274,10776,11181,13433,10955,11132,11184,13168,14339,14339,8064,361,7851,12640,13929,11257,11759,11868,12909,14199";
		String[] QualArray = QualityShop.split(",");
		return Arrays.asList(QualArray);
	}

	/**
	 * 生成新商家的列表
	 * 
	 * @return
	 */
	public static List<String> NewShop() {
		String NewShop = "13666,13698,13860,13765,13820,13824,13661,13715,13808,13837,13922,13492,14041,14044,12932,13822,13993,14048,14050,14051,14072,14106,14109,14158,14085,14140,14175,14191,14244,14266,14111,14208,14425,14332,14424,14579,13709,13766,13767,13823,13655,13831,13148,13891,13894,13925,14074,14083,14073,14204,13985,13988,13989,13990,14195,14226,14228,14241,14270,14290,14194,14271,14384,14473,14954,14662,13879,11609,12152,11947,13180,10927,14407,14022,14035,14036,13881,13270,13267,13151,13078,13019,13018,12976,12882,12848,12835,12832,12831,12768,12751,12748,12740,12685,12403,12347,12260,12258,12226,12018,11914,11802,11799,11645,11468,11353,11316,11255,11254,11124,11122,10949,10945,10936,10908,10906,10903,10857,10780,10766,10725,10687,10651,10632,10616,10615,10574,10526,10511,10510,10492,10424,10399,10304,10299,10253,10234,10197,10196,10193,10160,10157,10156,10124,10123,10120,10096,10058,10014,12774,13896,14020,14174,14380,14382,14453,14852,14447,14812,14776,13760,13932,14527,13764,13506,14422,13218,13543,13591,14043,14284,8555,13489,14854,14076,11111,13901,14173,14547,14545,13678,13333,14666,13886,9999,13322,10999,14701,13522,13681,13898,13948,14474,14503,14163,14009,14222,13061,13915,13046,13181,13453,13966,14200,13615,14114,13687,14844,14836,13929,14006,14222,14339,11257,14727,14201,13704,13704,12640,13433,11184";
		String[] NewArray = NewShop.split(",");
		return Arrays.asList(NewArray);
	}

	/**
	 * 验证指定商品是属于指定的商家列表
	 * 
	 * @param list
	 *            搜索结果中的商品列表
	 * @param split_pos
	 *            分割位置
	 * @param shoplist
	 *            制定的商品列表
	 * @return
	 */
	public static boolean doVerify(List<Node> list, int split_pos, List<String> shoplist, List<String> inshoplist) {
		// 用来记录上一个品的score分数
		int qua_pre_score = -1;

		// 循环遍历商品列表
		for (int i = 0; i < list.size(); i++) {
			// 得到商品的shop_id与score分
			String shop_id = XMLParser.product_shopID(list.get(i));
			String score = XMLParser.product_scope(list.get(i));
			String product_id = XMLParser.product_id(list.get(i));
			// 如果是制定商铺列表的
			if (shoplist.contains(shop_id)) {
				if (qua_pre_score == -1) {
					// 召回的品文本相关性要>=5
					if (!(TextRelation(score) >= 5)) {
						logger.error(" - [INSIDE] - "+" - The product text relative score is less than 5; product_id:" + product_id + " Score:" + score+" "+PositionQul(i)+PositionNew(i));
						return false;
					}
					qua_pre_score = Integer.valueOf(score);
					continue;
				} else {
					// 召回的品文本相关性要>=5
					if (!(TextRelation(score) >= 5)) {
						logger.error(" - [INSIDE] - "+" - The product text relative score is less than 5; product_id:" + product_id + " Score:" + score+" "+PositionQul(i)+PositionNew(i));
						return false;
					}
					//score分倒序
					if (qua_pre_score >= Integer.valueOf(score)) {
						qua_pre_score = Integer.valueOf(score);
						continue;
						
						//没有按照score分倒序
					} else {
						logger.error(" - [INSIDE] - "+" - Sort by score failed.pre_product:" + XMLParser.product_id(list.get(i - 1)) + " cur_product:" + product_id+" "+PositionQul(i)+PositionNew(i));
						logger.error(" - [INSIDE] - "+" - pre_product score:" + qua_pre_score + " cur_product score:" + score);
						return false;
					}
				}
				// 如果不是指定商铺列表中的
			} else {
				// 记录分割位置
				if (split_pos == 0) {
					split_pos = i;
				}
				// 记录上一个品的score分
				qua_pre_score = -1;

				// 遍历搜索结果中所有的品
				for (int j = i; j < list.size(); j++) {
					// 得到品的商铺信息与分数
					String tmp_shop_id = XMLParser.product_shopID(list.get(j));
//					String tmp_score = XMLParser.product_scope(list.get(j));
					// 分割点之后发现了非普通商家的品
					if (shoplist.contains(tmp_shop_id)) {
						logger.error(" - [INSIDE] - "+"The product type list is discontinuity.Position:"+PositionQul(j)+PositionNew(j));
						logger.error(" - [INSIDE] - "+"The product__id:"+XMLParser.product_id(list.get(j)));
						return false;

					} else {
						
//						if(inshoplist.contains(tmp_shop_id)){
//							if(!noProperProduct(ComPList, shoplist, inshoplist)){
//							logger.error(" - [INSIDE] - "+"Quality/New shop product is showing in incorrect position:"+PositionQul(j)+PositionNew(j)+" ;Shop_id:"+tmp_shop_id);
//							logger.error(" - [INSIDE] - "+"The product__id:"+XMLParser.product_id(list.get(j)));
//							return false;
//							}
//						}
						
						//补充的品，按照正常排序（包含打散），无法通过score比较进行验证
//						//初始化上一个品的score分
//						if (qua_pre_score == -1) {
//							qua_pre_score = Integer.valueOf(tmp_score);
//							continue;
//							//倒序
//						} else {
//							if (qua_pre_score >= Integer.valueOf(tmp_score)) {
//								qua_pre_score = Integer.valueOf(tmp_score);
//								continue;
//								
//								// 没有按照score分进行排序
//							} else {
//								logger.error(" - [INSIDE] - "+" - Sort by score failed.pre_product:" + XMLParser.product_id(list.get(j - 1)) + " cur_product:"
//										+ XMLParser.product_id(list.get(j))+" "+PositionQul(j)+PositionNew(j));
//								logger.error(" - [INSIDE] - "+" - pre_product score:" + qua_pre_score + " cur_product score:" + tmp_score);
//								return false;
//							}
//						}
					}
				}
				break;
			}
		}
//		logger.info(" - [INSIDE] - "+"DoVerify Successed!");
		return true;
	}

	
	public static String PositionQul(int index){
		int p_q = index/36+1;
		int i_q = temQulist.get(index%36);
		String str = String.format("[Quality Page: %d + Index: %d]", p_q,i_q);
		return str;
		
	}
	
	public static String PositionNew(int index){
		int p_q = index/6+1;
		int i_q = temNelist.get(index%6);
		String str = String.format("[New Page: %d + Index: %d]", p_q,i_q);
		return str;
		
	}
	
	public static String PositionCom(int index){
		int p_q = index/18+1;
		int i_q = temColist.get(index%18);
		String str = String.format("[Com Page: %d + Index: %d]", p_q,i_q);
		return str;
		
	}
	
	
	public static boolean noProperProduct(List<Node> nList,List<String> sListQul,List<String> sListNew){
		
		for(Node node: nList){
			String shop_id = XMLParser.product_shopID(node);
			if(sListQul.contains(shop_id) || sListNew.contains(shop_id)){
				continue;
			}else{
				String product_id = XMLParser.product_id(node);
				logger.error("ProperProduct--->  Common product  id:"+product_id+" Shop_id: "+shop_id);
				return false;
			}
		}
		return true;
	}
	
	/**
	 * 未进入新排序策略的，默认搜索结果按照综合分数排序 （只验证前5页）
	 * 
	 * @param iterator
	 * @return
	 */
	public static boolean SortScore(ProdIterator iterator) {
		// 保存上一个品的综合分数
		int pre_score = -1;
		String pre_product_id = null;
		// 遍历搜索结果
		while (iterator.hasNext() && iterator.getpageIndex() <= 5) {
			Node node = iterator.next();
			String score = XMLParser.product_scope(node);
			String cur_product_id = XMLParser.product_id(node);
			// 初始
			if (pre_score == -1) {
				pre_score = Integer.valueOf(score);
				pre_product_id = XMLParser.product_id(node);
				continue;
			} else {
				// 比较综合评分，降序展示
				if (pre_score >= Integer.valueOf(score)) {
					pre_score = Integer.valueOf(score);
					pre_product_id = XMLParser.product_id(node);
					return true;
				} else {
					logger.error(" - [OUTSIDE] - "+" - Sort by score failed.pre_product:" + pre_product_id + " cur_product:" + cur_product_id);
					logger.error(" - [OUTSIDE] - "+" - pre_product score:" + pre_score + " cur_product score:" + score);
					return false;
				}
			}
		}
		logger.info(" - [OUTSIDE] - "+"Successed");
		return true;

	}

	
	/**
	 * 验证结果中去除单品置顶
	 * @param list
	 * @return
	 */
	public static boolean rmTopProduct(List<Node> list){
		//前3个品
		for(int i=0;i<3;i++){
			String score = XMLParser.product_scope(list.get(i));
			String pidString = XMLParser.product_id(list.get(i));
			int i_score = Integer.valueOf(score);
			String b_score = Integer.toBinaryString(i_score);
			int length = b_score.length();
			//补齐31
			if(length<31){
				for(int j=0;j<31-length;j++){
					b_score = "0"+b_score;
				}
			}
			
			String topProduct = b_score.substring(0,3);
			
			//单品加权分为0
			if(!topProduct.equals("000")){
				logger.error(" - [INSIDE] - "+" Top product is not removed! product_id:"+pidString+" score:"+score+" bscore:"+b_score+"/"+topProduct);
				return false;
			}
			
			
		}
		
		
		return true;	
	}
	
	
	/**
	 * 得到文本相关性得分
	 * 
	 * @param score
	 *            商品的score得分
	 * @return
	 */
	public static int TextRelation(String score) {

		int iscore = Integer.valueOf(score);
		// 转成二进制
		String b_scope_full = Integer.toBinaryString(iscore);
		// 拿到文本相关性部分的得分
		String text_rel_full = b_scope_full.substring(b_scope_full.length() - 27, b_scope_full.length() - 24);
		// 从二进制重新转换成10进制
		int tr = Integer.parseInt(text_rel_full, 2);
		return tr;
	}

	public static void main(String[] args) {
		FuncQuery fquery = new FuncQuery();
		fquery.setFquery("风衣 女 春秋");
		System.out.println(verify(fquery));
		
	}

}
