package com.dangdang.data;

public class PidCatPaths {
	private int pid;
	private int category_id;
	private String cat_paths;
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public int getCategoryId() {
		return category_id;
	}
	public void setCategoryId(int category_id) {
		this.category_id = category_id;
	}
	public String getCatPaths() {
		return cat_paths;
	}
	public void setCatPaths(String cat_paths) {
		this.cat_paths = cat_paths;
	}

}
