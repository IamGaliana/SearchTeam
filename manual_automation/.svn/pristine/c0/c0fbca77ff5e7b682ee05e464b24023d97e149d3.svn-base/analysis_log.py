﻿#!/usr/bin/python
#!encoding:utf-8
import sys
import re

args = sys.argv
if len(args)<2:
	print 'Please start with [LOG] file'
	exit(1)

logfile = args[1]
regpat = re.compile('pool-\d+-thread-\d+:')
part_files = {}
all_result = []
def split_file():
	global logfile, part_files
	with open(logfile, 'r') as f:
		for l in f:
			if not l.strip():
				continue
			matchs = regpat.search(l)
			if matchs:
				matchs = matchs.group()
				if matchs not in part_files:
					part_files[matchs] = []
				part_files[matchs].append(l)
			else:
				print l

def write_file():
	global part_files, all_result
	for k,v in part_files.items():
		with open(r'logs/%s.log'%k[:-1], 'w') as w:
			w.writelines(v)
		tc = []
		td = {
			'name' : 'null',
			'time' : 0,
			'pass' : 0,
			'skip' : 0,
			'excp' : 0,
			'noresult' : 0, 
			'checkfail' : 0,
			'total' : 0
		}
		i = 0
		for l in v:
			if '[ ERROR ]' in l:
				tc.extend(v[i-1:i+1])
				if 'LOG_SKIP' in l:
					td['skip'] += 1
				elif 'LOG_EXCE' in l:
					td['excp'] += 1
				elif 'NO-RESULT' in l:
					td['noresult'] += 1
				elif 'CHECK-FAIL' in l:
					td['checkfail'] += 1
			elif 'LOG_SUMMARY' in l:
				tc.append(l)
				arr = l.split('[LOG_SUMMARY] - ')[1].split(',')
				rpass, rfail, rskip = [s.split(':')[1].strip() for s in arr]
			elif 'eslipse' in l:
				name, t = l.split('eslipse for ')[1].split(':')
				td['name'] = name
				td['time'] = t
			i += 1
		with open(r'logs/%s_error.log'%td['name'], 'w') as w:
			w.writelines(tc)    
		td['total'] = rpass + rfail + rskip;
		all_result.append(td)
	part_files = None
			
def report():
	global all_result
	t = '''<html xmlns="http://www.w3.org/1999/xhtml" lang="zh-cn">
		<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
		<title>搜索测试报告</title>
		</head>
		<body><table><tr>
		<td>模块名称</td>
		<td>&nbsp;PASS&nbsp;</td>
		<td>&nbsp;SKIP&nbsp;</td>
		<td>&nbsp;EXCP&nbsp;</td>
		<td>&nbsp;NoResult&nbsp;</td>
		<td>&nbsp;CheckFail&nbsp;</td>
		<td>&nbsp;Total&nbsp;</td>
		<td>&nbsp;Eslipse&nbsp;</td>
		</tr>'''
	for tr in all_result:
		t += '''<tr>
		<td>%(name)s</td>
		<td>%(pass)s</td>
		<td>%(skip)s</td>
		<td>%(excp)s</td>
		<td>%(noresult)s</td>
		<td>%(checkfail)s</td>
		<td>%(total)s</td>
		<td>%(time)s</td>
		</tr>''' % tr
	t += '''</table></body></html>'''	
	print t
	with open(r'logs/report.html', 'w') as w:
		w.writelines(t)
	
def main():
	split_file()
	write_file()
	report()

if __name__=='__main__':
	main()
